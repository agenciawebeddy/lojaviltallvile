ALTER TABLE public.product_variants
ADD COLUMN color_name TEXT;