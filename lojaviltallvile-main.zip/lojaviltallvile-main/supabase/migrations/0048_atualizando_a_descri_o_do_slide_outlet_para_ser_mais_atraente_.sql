UPDATE public.hero_slides
SET description = 'Não perca! Descontos imperdíveis em produtos selecionados. Estoque limitado!'
WHERE button_link = '/shop/outlet';