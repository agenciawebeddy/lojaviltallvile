ALTER TABLE public.store_settings
ADD COLUMN store_logo_url TEXT;