ALTER TABLE public.products
ADD COLUMN IF NOT EXISTS melhor_envio_product_id TEXT;