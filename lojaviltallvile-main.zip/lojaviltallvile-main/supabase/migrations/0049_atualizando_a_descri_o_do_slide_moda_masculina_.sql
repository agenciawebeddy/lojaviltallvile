UPDATE public.hero_slides
SET description = 'Descubra as últimas tendências em vestuário e acessórios masculinos. Estilo e qualidade garantidos.'
WHERE button_link = '/shop/masculino';