INSERT INTO storage.buckets (id, name, public)
VALUES ('social-icons', 'social-icons', true);