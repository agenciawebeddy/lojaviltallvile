ALTER TABLE public.products
ADD COLUMN discount_price NUMERIC;