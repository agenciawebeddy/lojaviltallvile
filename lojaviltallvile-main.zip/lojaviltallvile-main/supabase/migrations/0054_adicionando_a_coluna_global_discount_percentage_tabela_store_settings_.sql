ALTER TABLE public.store_settings
ADD COLUMN global_discount_percentage NUMERIC DEFAULT 0.00;