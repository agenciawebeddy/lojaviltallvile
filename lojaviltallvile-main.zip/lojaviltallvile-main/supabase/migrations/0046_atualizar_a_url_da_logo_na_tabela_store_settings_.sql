UPDATE public.store_settings
SET store_logo_url = 'https://hqwujtzlhwycndpfqjvd.supabase.co/storage/v1/object/public/store-logos/logo-vitalville.png'
WHERE id = 1;