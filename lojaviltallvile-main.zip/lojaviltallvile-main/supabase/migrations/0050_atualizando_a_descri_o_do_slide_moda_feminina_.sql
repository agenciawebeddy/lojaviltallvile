UPDATE public.hero_slides
SET description = 'Renove seu guarda-roupa com peças exclusivas e elegantes. Encontre o look perfeito para qualquer ocasião.'
WHERE button_link = '/shop/feminino';